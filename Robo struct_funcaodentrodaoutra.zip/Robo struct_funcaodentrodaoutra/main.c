#include <stdio.h>
#include <stdlib.h>

typedef struct sensores    {    int S1;
                                int S2;
                           }sensor;



typedef struct motores    {    int M1;
                               int M2;
                          }motor;



sensor lerSensor(void){

    int d1, d2, x, y;
    printf("Digite o valor da distancia do sensor 1: ");
    scanf("%d", &d1);

    printf("Digite o valor da distancia do sensor 2: ");
    scanf("%d", &d2);

    if(d1 < 50){
        x = 1;
    }else{
        x = 0;
    }

    if(d2 < 50){
        y = 1;
    }else{
        y = 0;
    }

    sensor lerSensor_sensor = {x, y};
    return lerSensor_sensor;
}



motor ia(sensor ia_sensor){

    motor ia_motor;

    if(ia_sensor.S2 == 1 && ia_sensor.S1 == 1){
        ia_motor.M1 = 1;
        ia_motor.M2 = 0;
    }

    else if(ia_sensor.S2 == 0 && ia_sensor.S1 == 1){
        ia_motor.M1 = 1;
        ia_motor.M2 = 0;
    }

    else if(ia_sensor.S2 == 1 && ia_sensor.S1 == 0){
        ia_motor.M1 = 0;
        ia_motor.M2 = 1;
    }

    else if(ia_sensor.S2 == 0 && ia_sensor.S1 == 0){
        ia_motor.M1 = 1;
        ia_motor.M2 = 1;
    }

    return ia_motor;
}



void driveMotors(motor drive_motor){

    printf("\rMotor 1: %d\nMotor 2: %d", drive_motor.M1, drive_motor.M2);
}



int main(){

    sensor main_sensor;
    motor main_motor;

    while(1){
        driveMotors(ia(lerSensor()));

        getch();
        system("cls");
    }

    return 0;
}
